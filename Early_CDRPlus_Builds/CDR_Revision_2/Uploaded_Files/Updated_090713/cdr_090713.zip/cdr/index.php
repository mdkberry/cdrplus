<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<title>CDR Reporter - Ext Based</title>

<script type='text/javascript' src='js/jquery-1.7.1.min.js'></script>
<style type="text/css">
a {
	color: white; text-decoration: none; font-weight: bold; font-family: helvetica; font-size: 20px;	
}
a:hover {
	color: blue;
}
</style>
</head>
<body>
<div style="margin: 100px auto; background: none repeat scroll 0% 0% black; width: 600px; text-align: center;font-weight : bold;" > 
	<div style="color: yellow; padding: 30px 0px; font-size: 26px; font-family: Helvetica; font-weight: bold;" >CDRPlus</div>
	<div style="padding: 33px 0 16px" ><a href="live_call.php">Live Call Display</a></div>
	<div style="padding: 16px 0;" ><a href="reports.php">Call Reports</a></div>
	<div style="padding: 16px 0 65px;" ><a href="user_settings.php">Settings</a></div>
</div>
</body>

</html>
