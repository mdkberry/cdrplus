-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 22, 2013 at 02:06 AM
-- Server version: 5.5.25a
-- PHP Version: 5.3.8-ZS5.5.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `membership`
--

-- --------------------------------------------------------

--
-- Table structure for table `rotation_config`
--

CREATE TABLE IF NOT EXISTS `rotation_config` (
  `call_today` varchar(255) DEFAULT NULL,
  `call_this_week` varchar(255) DEFAULT NULL,
  `call_this_month` varchar(255) DEFAULT NULL,
  `team_today` varchar(255) DEFAULT NULL,
  `team_this_week` varchar(255) DEFAULT NULL,
  `team_this_month` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rotation_config`
--

INSERT INTO `rotation_config` (`call_today`, `call_this_week`, `call_this_month`, `team_today`, `team_this_week`, `team_this_month`) VALUES
('1', '1', '1', '1', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE IF NOT EXISTS `schedule` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `mail` varchar(255) NOT NULL,
  `extlist` varchar(255) DEFAULT NULL,
  `fromdate` date DEFAULT NULL,
  `todate` date DEFAULT NULL,
  `period` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `fordisplay` varchar(10) NOT NULL DEFAULT 'no',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `report_run` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `report_run_exec` varchar(10) NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=80 ;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`id`, `mail`, `extlist`, `fromdate`, `todate`, `period`, `type`, `fordisplay`, `created`, `report_run`, `report_run_exec`) VALUES
(78, 'susri', NULL, '2012-02-03', '2013-02-12', NULL, 'callcount', 'no', '2013-02-21 06:44:09', '2013-02-12 15:59:59', 'yes'),
(79, 'susri1', NULL, NULL, NULL, 'weekly', 'callcount', 'no', '2013-02-21 06:44:43', '2013-02-24 15:59:59', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `extension` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `user`, `group`, `extension`) VALUES
(1, 'admin', 'administrator', 'null'),
(2, 'reports', 'Reports', 'null'),
(3, 'Reception', 'extension', '500'),
(4, 'Frances', 'extension', '501'),
(5, 'Sarah', 'HR', '502'),
(6, 'Olya', 'HR', '503'),
(7, 'Preyaz', 'HR', '505'),
(8, 'Dale', 'SALES', '506'),
(9, 'Juan', 'SALES', '507'),
(10, 'Tyron', 'MANAGER', '508'),
(11, 'Larry', 'MANAGER', '509'),
(12, 'Dave', 'SALES', '510'),
(13, 'Matilda', 'OPS', '512'),
(14, 'Vince', 'OPS', '513'),
(15, 'Samantha', 'OPS', '514'),
(16, 'Michael', 'OPS', '515'),
(17, 'Blake', 'OPS', '518'),
(18, 'Kourtney', 'OPS', '519');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
