<?php
	include 'db.php';
	
	global $locallink;
	
	$q = "SELECT * FROM rotation_config";
	$cfg = mysql_query($q, $locallink);
	$cfg = mysql_fetch_assoc($cfg);
	
	echo json_encode($cfg);
?>