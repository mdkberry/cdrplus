<?php
	$locallink = mysql_connect("localhost", "root", "") or die("Unable to connect to local MySQL server");
	mysql_select_db("membership", $locallink) or die("Unable to select database at local DB");
	
	$remotelink = mysql_connect("10.10.20.5", "root", "M3d1@C0rp") or die("Unable to connect to remote MySQL server");
	mysql_select_db("asteriskcdrdb", $remotelink) or die("Unable to select database at remote DB");
	
	$ignoreList = array('000', 's', '*97');
		
	function getExtList()
	{
		global $locallink;
		$extlist = array();
		
		$query = "SELECT extension FROM acl_user ORDER BY extension ASC";
		$exts = mysql_query($query, $locallink);
		while($row = mysql_fetch_assoc($exts))
		{
			if(empty($row['extension'])) continue;
			
			$extlist[] = $row['extension'];
		}
				
		return $extlist;
	}
	
	function getTeamList()
	{
		global $locallink;
		$teamlist = array();

		$query = "SELECT acl_group.name, extension FROM acl_group, acl_user, acl_membership 
				  WHERE acl_group.id = acl_membership.id_group AND acl_user.id = acl_membership.id_user
				  ORDER BY acl_group.name";
		
		$teams = mysql_query($query, $locallink);
		
		while($row = mysql_fetch_assoc($teams))
		{
			if(empty($row['name']) || empty($row['extension'])) continue;
			
			if( !isset($teamlist[$row['name']]) ) $teamlist[$row['name']] = array();
			$teamlist[$row['name']][] = $row['extension'];
		}
				
		return $teamlist;
	}
	
	$extlist = getExtList();
	$teamlist = getTeamList();
	$FIRSTEXT = $extlist[0];
	$LASTEXT =  $extlist[count($extlist) - 1];

	function getCheckValid($cdr)
	{
		global $FIRSTEXT;
		global $LASTEXT;
		global $ignoreList;
		
		$srcInRange = ($cdr['src'] < $FIRSTEXT || $cdr['src'] > $LASTEXT || in_array($cdr['src'], $ignoreList)) ? 0 : 1; 
		$dstInRange = ($cdr['dst'] < $FIRSTEXT || $cdr['dst'] > $LASTEXT || in_array($cdr['dst'], $ignoreList)) ? 0 : 1;

		if( ($srcInRange + $dstInRange) != 1 ) return array("isValid" => false, "thisExt" => "", "outExt" => "" );
		
		if( $srcInRange == 1)
			return array("isValid" => true, "thisExt" => $cdr['src'], "outExt" => $cdr['dst'] );
		else 
			return array("isValid" => true, "thisExt" => $cdr['dst'], "outExt" => $cdr['src'] );
	}

	function extractExtData($start, $end)
	{
//		echo $start." - ".$end;
		global $remotelink;
		
		$CALL1MIN = array();
		$CALL5MIN = array();
		$CALLPLUS5 = array();
		$CALLSEC = array();
		$CALLCOUNTX = array();
		$DIALEDNUM = array();
		$UNIQ = array();
		
		$q = "SELECT * FROM cdr WHERE calldate BETWEEN '$start' AND '$end'";
		$cdrs = mysql_query($q, $remotelink);
		while($cdr = mysql_fetch_assoc($cdrs))
		{
			$check = getCheckValid($cdr);
			if($cdr['billsec'] <= 0) continue; 	
			
			if( !$check["isValid"] ) continue;
			
			$THISEXT = $check['thisExt'];
			$OUTEXT = $check['outExt'];
			
			if(!isset($CALL1MIN[$THISEXT]))  $CALL1MIN[$THISEXT] = 0;
			if(!isset($CALL5MIN[$THISEXT]))  $CALL5MIN[$THISEXT] = 0;
			if(!isset($CALLPLUS5[$THISEXT])) $CALLPLUS5[$THISEXT] = 0;
			if(!isset($CALLSEC[$THISEXT]))   $CALLSEC[$THISEXT] = 0;
			if(!isset($UNIQ[$THISEXT]))      $UNIQ[$THISEXT] = 0;

			$len = $cdr['billsec'];
			 
			if( $len < 60)		{	$CALL1MIN[$THISEXT]++;	}
			else if($len < 300)	{	$CALL5MIN[$THISEXT]++;	}
			else				{	$CALLPLUS5[$THISEXT]++;	}
			
			$CALLSEC[$THISEXT] += $len;
			
//			$CALLCOUNTX[$THISEXT]++;
			
			if(!isset($DIALEDNUM[$OUTEXT])) { $DIALEDNUM[$OUTEXT] = "dialed"; $UNIQ[$THISEXT]++; } 
			   
		}
		
		return array("call1min" => $CALL1MIN, "call5min" => $CALL5MIN, "callplus5" => $CALLPLUS5,
					 "uniqcalls" => $UNIQ, "totaltime" => $CALLSEC	);
	}
	
	function getTop3Ext($calls)
	{
		$tops = array();
		
		foreach ($calls as $ext => $call)
		{
			if(!isset($calls[$ext])) continue;
			
			$inserted = false;
			
			for($i = 0; $i < count($tops) && $i < 3 ; $i++)
			{
				if( $calls[$tops[$i]] >= $call ) continue;

				$j = (count($tops) > 2) ? 1 : count($tops) - 1; 
				for(; $j >= $i; $j--) {$tops[$j + 1] = $tops[$j]; }
				$tops[$i] = $ext;
				
				$inserted = true; break;
			}
			
			if(!$inserted && count($tops) < 3) $tops[] = $ext; 
		}
		
		return $tops;
	}
	
	function extractTeamData($start, $end)
	{
		$extdata = extractExtData($start, $end);
		
		$teamlist = getTeamList();
		
		$extUNIQ = $extdata['uniqcalls'];
		$extCALL = $extdata['totaltime'];
		
		$teamUNIQ = array();
		$teamCALL = array();
		$teamTOP = array();
		
		foreach ($teamlist as $team => $extList) {
			if(!isset($teamUNIQ[$team])) $teamUNIQ[$team] = 0;
			if(!isset($teamCALL[$team])) $teamCALL[$team] = 0;
			if(!isset($teamTOP[$team]))  $teamTOP[$team] = array();

			$teamCalls = array();
			
			foreach ($extList as $ext)
			{
				$teamUNIQ[$team] += isset($extUNIQ[$ext]) ? $extUNIQ[$ext] : 0;
				$teamCALL[$team] += isset($extCALL[$ext]) ? $extCALL[$ext] : 0;
				if(isset($extCALL[$ext])) $teamCalls[$ext] = $extCALL[$ext];
			}

			$teamTOP[$team] = getTop3Ext($teamCalls);	
		}
		
		return array("uniqcalls" => $teamUNIQ, "totaltime" => $teamCALL, "top3" => $teamTOP);
	}
	
	function paddingZero($n) {	if($n < 10) return "0".$n; return $n; }	

	function getTimeFormated($sec)
	{
		$hour = floor($sec / 3600);
		$mins = floor(($sec % 3600 ) / 60);
		$secs = $sec % 60;
		 
		return paddingZero($hour).":".paddingZero($mins).":".paddingZero($secs);
	}
	
?>